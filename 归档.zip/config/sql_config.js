/*
 * @Author: wkiwi
 * @Email: w_kiwi@163.com
 * @Date: 2018-11-17 14:44:05
 * @LastEditors: wkiwi
 * @LastEditTime: 2018-11-23 17:26:37
 */

module.exports = {
  host     : 'localhost',
  user     : 'root',
  password : 'root123',
  database : 'koacms'
}